﻿namespace CandiULB
{
    partial class CandiULBArchiverGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxUsername = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.tbxOutputDirectory = new System.Windows.Forms.TextBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblOutputDirectory = new System.Windows.Forms.Label();
            this.fbdOutputDirectory = new System.Windows.Forms.FolderBrowserDialog();
            this.btnBrowseOutputDirectory = new System.Windows.Forms.Button();
            this.lblDetails = new System.Windows.Forms.Label();
            this.tbxDetails = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbxExcludedThreads = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbxPause = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tbxUsername
            // 
            this.tbxUsername.Location = new System.Drawing.Point(87, 12);
            this.tbxUsername.Name = "tbxUsername";
            this.tbxUsername.Size = new System.Drawing.Size(161, 20);
            this.tbxUsername.TabIndex = 0;
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStart.Location = new System.Drawing.Point(56, 395);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(634, 28);
            this.btnStart.TabIndex = 5;
            this.btnStart.Text = "Go!";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // tbxOutputDirectory
            // 
            this.tbxOutputDirectory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxOutputDirectory.BackColor = System.Drawing.SystemColors.Window;
            this.tbxOutputDirectory.Location = new System.Drawing.Point(87, 64);
            this.tbxOutputDirectory.Name = "tbxOutputDirectory";
            this.tbxOutputDirectory.Size = new System.Drawing.Size(534, 20);
            this.tbxOutputDirectory.TabIndex = 3;
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(12, 15);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(43, 13);
            this.lblUsername.TabIndex = 10;
            this.lblUsername.Text = "Pseudo";
            // 
            // lblOutputDirectory
            // 
            this.lblOutputDirectory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOutputDirectory.AutoSize = true;
            this.lblOutputDirectory.Location = new System.Drawing.Point(12, 67);
            this.lblOutputDirectory.Name = "lblOutputDirectory";
            this.lblOutputDirectory.Size = new System.Drawing.Size(56, 13);
            this.lblOutputDirectory.TabIndex = 14;
            this.lblOutputDirectory.Text = "Répertoire";
            // 
            // btnBrowseOutputDirectory
            // 
            this.btnBrowseOutputDirectory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBrowseOutputDirectory.Location = new System.Drawing.Point(627, 64);
            this.btnBrowseOutputDirectory.Name = "btnBrowseOutputDirectory";
            this.btnBrowseOutputDirectory.Size = new System.Drawing.Size(63, 20);
            this.btnBrowseOutputDirectory.TabIndex = 4;
            this.btnBrowseOutputDirectory.Text = "Choisir";
            this.btnBrowseOutputDirectory.UseVisualStyleBackColor = true;
            this.btnBrowseOutputDirectory.Click += new System.EventHandler(this.btnBrowseOutputDirectory_Click);
            // 
            // lblDetails
            // 
            this.lblDetails.AutoSize = true;
            this.lblDetails.Location = new System.Drawing.Point(11, 93);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(39, 13);
            this.lblDetails.TabIndex = 15;
            this.lblDetails.Text = "Détails";
            // 
            // tbxDetails
            // 
            this.tbxDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxDetails.BackColor = System.Drawing.SystemColors.Window;
            this.tbxDetails.Location = new System.Drawing.Point(56, 90);
            this.tbxDetails.Multiline = true;
            this.tbxDetails.Name = "tbxDetails";
            this.tbxDetails.ReadOnly = true;
            this.tbxDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbxDetails.Size = new System.Drawing.Size(634, 299);
            this.tbxDetails.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Sujets exclus";
            // 
            // tbxExcludedThreads
            // 
            this.tbxExcludedThreads.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxExcludedThreads.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxExcludedThreads.Location = new System.Drawing.Point(87, 38);
            this.tbxExcludedThreads.Name = "tbxExcludedThreads";
            this.tbxExcludedThreads.Size = new System.Drawing.Size(534, 20);
            this.tbxExcludedThreads.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(363, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(213, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Pause entre chaque requête (millisecondes)";
            // 
            // tbxPause
            // 
            this.tbxPause.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbxPause.Location = new System.Drawing.Point(582, 12);
            this.tbxPause.Name = "tbxPause";
            this.tbxPause.Size = new System.Drawing.Size(39, 20);
            this.tbxPause.TabIndex = 1;
            // 
            // CandiULBArchiverGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 435);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbxPause);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbxExcludedThreads);
            this.Controls.Add(this.lblDetails);
            this.Controls.Add(this.tbxDetails);
            this.Controls.Add(this.btnBrowseOutputDirectory);
            this.Controls.Add(this.lblOutputDirectory);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.tbxOutputDirectory);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.tbxUsername);
            this.Name = "CandiULBArchiverGUI";
            this.Text = "Archiveur CandiULB";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxUsername;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.TextBox tbxOutputDirectory;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblOutputDirectory;
        private System.Windows.Forms.FolderBrowserDialog fbdOutputDirectory;
        private System.Windows.Forms.Button btnBrowseOutputDirectory;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.TextBox tbxDetails;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxExcludedThreads;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbxPause;
    }
}

