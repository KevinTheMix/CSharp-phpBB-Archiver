﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CandiULB.API
{
    public static class Tools
    {
        /// <summary>
        /// Checks whether a given string is present in a given list of strings.
        /// String extension method.
        /// </summary>
        /// <param name="source">The string to look-up.</param>
        /// <param name="list">The list of strings in which to look-up.</param>
        /// <returns>True if the source string is present in the list.</returns>
        public static bool In(this string source, params string[] list)
        {
            if (null == source) throw new ArgumentNullException("source");            
            foreach (string text in list)
                if (source == text)
                    return true;
            return false;
        }

        public static string HtmlToText(string html)
        {
            return System.Web.HttpUtility.HtmlDecode(html);            
        }
        public static string IsoToText(string text)
        {
            Encoding iso = Encoding.GetEncoding("ISO-8859-1");
            Encoding utf8 = Encoding.UTF8;

            byte[] isoData = iso.GetBytes(text);
            byte[] utfData = Encoding.Convert(iso, utf8, isoData);
            return utf8.GetString(utfData);

            //byte[] utfData = utf8.GetBytes(text);
            //byte[] isoData = Encoding.Convert(utf8, iso, utfData);
            //return utf8.GetString(isoData);

            return text;
        }

        public static byte[] TextToData(string text)
        {
            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            return encoding.GetBytes(text);
        }
        public static string DataToText(byte[] data)
        {
            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            return encoding.GetString(data);
        }
    }
}
