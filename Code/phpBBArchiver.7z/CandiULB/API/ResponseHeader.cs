﻿using System;

namespace CandiULB.API
{
    public class ResponseHeader
    {
        protected string _Connection;
        protected string _ProxyConnection;
        protected string _TransferEncoding;
        protected string _Date;
        protected string _SetCookie;
        protected string _Server;
        protected string _Via;
        protected string _XPoweredBy;
        protected string _KeepAlive;

        public ResponseHeader(string connection, string proxyConnection, string transferEncoding, string date, string setCookie,
            string server, string via, string xPoweredBy, string keepAlive)
        {
            _Connection = connection;
            _ProxyConnection = proxyConnection;
            _TransferEncoding = transferEncoding;
            _Date = date;
            _SetCookie = setCookie;
            _Server = server;
            _Via = via;
            _XPoweredBy = xPoweredBy;
            _KeepAlive = keepAlive;
        }

        public string Connection
        { get { return _Connection; } }
        public string ProxyConnection
        { get { return this._ProxyConnection; } }
        public string TransferEncoding
        { get { return this._TransferEncoding; } }
        public string Date
        { get { return this._Date; } }
        public string SetCookie
        { get { return this._SetCookie; } }
        public string Server
        { get { return this._Server; } }
        public string Via
        { get { return this._Via; } }
        public string XPoweredBy
        { get { return this._XPoweredBy; } }
        public string KeepAlive
        { get { return this._KeepAlive; } }

        public override string ToString()
        {
            return string.Format(@"Connection = {1}{0}Proxy Connection = {2}{0}Transfer Encoding = {3}{0}Date = {4}{0}Set Cookie = {5}{0}Server = {6}{0}Via = {7}{0}X Powered By = {8}{0}Keep Alive = {9}{0}",
                Environment.NewLine, this._Connection, this._ProxyConnection, this._TransferEncoding, this._Date, this._SetCookie, this._Server,
                this._Via, this._XPoweredBy, this._KeepAlive);
        }
    }
}
