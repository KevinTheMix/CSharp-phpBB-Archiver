﻿using System;
using System.Windows.Forms;
using CandiULB.API;

namespace CandiULB
{
    public partial class CandiULBArchiverGUI : Form
    {
        private const string DEFAULT_PAUSE = "0";
        protected CandiULBArchiver _Archiver;
        public CandiULBArchiverGUI()
        {
            InitializeComponent();

            // CandiULB archiver.
            _Archiver = new CandiULBArchiver(this.tbxDetails);

#if DEBUG
            this.tbxUsername.Text = "Marvelous";
            this.tbxOutputDirectory.Text = @"C:\Kevin\Working Folders\Tools\CandiULB\IO\Auto";
#endif
            this.tbxPause.Text = "100";
            this.tbxExcludedThreads.Text = string.Format("[{0}]+[{1}]+[{2}]+[{3}]+[{4}]+[{5}]+[{6}]+[{7}]+[{8}]+[{9}]+[{10}]+[{11}]+[{12}]+[{13}]+[{14}]+[{15}]+[{16}]+[{17}]",
                "Happy birthday",
                "hip hip",
                "Jeu",
                "Jeu citations",
                "Le célibat",
                "Le Cybercafé",
                "Pinned:  Concours de la blague la plus nulle",
                "Pinned:  Concours : Crache ta haine ou ton désespoir",
                "Pinned:  concours : crie ta joie ou ta bonne humeur",
                "Pinned:  Diverses enroules variés d'humour rigolo",
                "Pinned:  Heureux la femme ou l'homme qui ...",
                "Pinned:  Interrogations inclassables...",
                "Pinned:  Les films à ne voir sous aucun prétexte",
                "Pinned:  Les films que vous avez aimés ...",
                "Pinned:  Nos GRIMACES!!!",
                "Pinned:  Portrait Chinois",
                "Pinned:  Précédence",
                "Pinned:  Recommandations de la journée");
        }

        private void btnBrowseOutputDirectory_Click(object sender, System.EventArgs e)
        {
            this.fbdOutputDirectory.ShowDialog(this);
            this.tbxOutputDirectory.Text = this.fbdOutputDirectory.SelectedPath;
        }
        private bool IsGUIReadyToStart()
        {
            if (string.IsNullOrEmpty(this.tbxUsername.Text) || this.tbxUsername.Text.Length < 3)
            {
                this.tbxDetails.Text = "Le pseudo manque ou est trop court (au moins 3 caractères).";
                return false;
            }
            if (string.IsNullOrEmpty(this.tbxPause.Text))
            {
                this.tbxPause.Text = DEFAULT_PAUSE;
            }
            int pause;
            if (!int.TryParse(this.tbxPause.Text, out pause) || pause < 0)
            {
                this.tbxDetails.Text = "La pause en millisecondes entre les requêtes doit être un entier plus grand que 0.";
            }
            if (string.IsNullOrEmpty(this.tbxOutputDirectory.Text))
            {
                this.tbxDetails.Text = "Le répertoire de destination manque.";
                return false;
            }
            this.tbxDetails.Text = string.Empty;
            return true;
        }
        private void btnStart_Click(object sender, System.EventArgs e)
        {
            if (!IsGUIReadyToStart())
                return;

            // Lock the GUI.
            this.btnBrowseOutputDirectory.Enabled = false;
            this.btnStart.Enabled = false;

            // Run.
            int pause = Convert.ToInt32(this.tbxPause.Text);
            string excludedThreadsText = this.tbxExcludedThreads.Text;
            string[] excludedThreads = null;
            if (string.IsNullOrEmpty(excludedThreadsText) || excludedThreadsText.Length < 2 || excludedThreadsText[0] != '[' || excludedThreadsText[excludedThreadsText.Length - 1] != ']')
                excludedThreads = new string[0];
            else
                excludedThreads = excludedThreadsText.Substring(1, excludedThreadsText.Length - 2).Split(new string[] { "]+[" }, StringSplitOptions.None);

            _Archiver.Run(this.tbxUsername.Text, pause, excludedThreads, this.tbxOutputDirectory.Text);

            // Unlock the GUI.            
            this.btnBrowseOutputDirectory.Enabled = true;
            this.btnStart.Enabled = true;
        }        
    }
}
