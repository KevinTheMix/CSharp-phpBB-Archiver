﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using HtmlAgilityPack;

namespace CandiULB.API
{
    public class CandiULBArchiver
    {
        #region Members
        private const string SEARCH_TARGET_PAGE = "http://www.candiulb.be/forum/index.php?act=Search&CODE=01";
        private const string SEARCH_POST_PARAMETERS = "keywords=&namesearch={0}&exactname=1&forums%5B%5D=all&searchsubs=1&prune=0&prune_type=newer&sort_key=last_post&sort_order=asc&search_in=posts&result_type=posts";

        private const string SOLUTION_REFERENCES_PATH = ".\\References";        
        private const string CSS_FOLDER = "css\\";
        private const string IMAGES_FOLDER = ".\\images\\";
        private const string JS_FOLDER = ".\\js\\";

        protected System.Windows.Forms.TextBox _TbxDetails;        
        #endregion Members

        #region Constructor & Public Methods
        public CandiULBArchiver(System.Windows.Forms.TextBox tbxDetails)
        {
            this._TbxDetails = tbxDetails;
        }

        /// <summary>
        /// ------------------------------------------------------------------------------------------
        /// The logic is as follows. Note that some threads hav been excluded due to its size.
        /// ------------------------------------------------------------------------------------------
        /// Get the redirect page by sending a POST request with the username to the search page
        /// if the member does not exist OR there was request flood OR the user had written no messages
        /// {
        ///      show the error to the user
        ///      return
        /// }            
        /// Get the initial search results page in the META tag of the redirect page
        /// for each results page
        ///      for each thread
        ///          if thread title has not yet been archived AND the thread title != one of the specified long ones
        ///              Get message URL
        ///              Get thread landing page URL from HTTP 302 redirect
        ///              Strip thread landing page url to get thread base url (which is also the first page)
        ///              if thread contains several pages            
        ///                  for each page
        ///                      Save page as "[thread#].[page#].html"
        ///              else
        ///                  Save page as "[thread#].html"
        /// ------------------------------------------------------------------------------------------
        /// Note: Replace all the web references to internal references and local copy of CSS & JS.
        /// ------------------------------------------------------------------------------------------
        /// </summary>
        /// <param name="username">The username of the CandiULB user.</param>
        /// <param name="pause">The pause in milliseconds between GET requests to the server. Used to mitigate timeouts.</param>
        /// <param name="excludedThreads">A list of titles of threads for which no copy must be created (e.g. because they are too long).</param>
        /// <param name="outputDirectory">The directory in which the copies of the threads will be created.</param>
        public void Run(string username, int pause, string[] excludedThreads, string outputDirectory)
        {
            try
            {
                // Create the output directory if it doesn't exist and makes a copy of all the references (css, images, js).
                PrepareOutput(outputDirectory);

                #region Feedback
                this._TbxDetails.Text += string.Format("Recherche des messages pour \"{0}\" {1}", username, Environment.NewLine);
                this._TbxDetails.Refresh();
                #endregion Feedback

                // Get the URL of the search results page, then GET that page's content.
                string resultPageUrl = GetSearchResultPageUrl(username);
                string resultPageHtmlText = GetPageHtmlByGet(resultPageUrl, pause);

                // Get the number of results pages. Also retrieve the result page html.
                HtmlDocument resultPageHtml;
                int numberOfResultPages = GetNumberOfResultPages(resultPageHtmlText, out resultPageHtml);

                #region Feedback
                this._TbxDetails.Text += string.Format("--> {0} pages de résultats trouvés{1}{1}", numberOfResultPages, Environment.NewLine);
                this._TbxDetails.Refresh();
                #endregion Feedback

                #region Result pages
                int threadIndex = 0;
                Dictionary<string, int> threads = new Dictionary<string, int>();                
                for (int resultPageIndex = 1; resultPageIndex <= numberOfResultPages; resultPageIndex++)
                {
                    #region Feedback
                    this._TbxDetails.Text += string.Format("---------- Page {0} ----------{1}", resultPageIndex, Environment.NewLine);
                    this._TbxDetails.Refresh();
                    #endregion Feedback

                    // Browse all the messages on the result page, follows the corresponding threads and copies all their pages.
                    BrowseResultPage(resultPageHtml, ref threads, ref threadIndex, pause, excludedThreads, outputDirectory);

                    if (resultPageIndex <= numberOfResultPages)
                    {
                        // Load the next result page. This is done simply by appending "st=N" where N is a multiple of 25 (e.g. "st=25", "st=50").
                        string nextResultPageUrl = resultPageUrl + "&st=" + 25 * resultPageIndex;
                        resultPageHtmlText = GetPageHtmlByGet(nextResultPageUrl, pause);
                        resultPageHtml.LoadHtml(resultPageHtmlText);
                    }
                }
                #endregion Result pages

                #region Index
                // Creates the Index file.
                StringBuilder threadsIndex = new StringBuilder();
                foreach (KeyValuePair<string, int> thread in threads)
                    threadsIndex.AppendLine(thread.Value + "\t" + thread.Key);
                string indexFileName = "Index.txt";
                string indexFilePath = Path.Combine(outputDirectory, indexFileName);
                File.WriteAllText(indexFilePath, threadsIndex.ToString());
                #endregion Index

                #region Feedback
                this._TbxDetails.Text += "-------------" + Environment.NewLine;
                this._TbxDetails.Text += "Terminé!" + Environment.NewLine + Environment.NewLine;
                this._TbxDetails.Refresh();
                #endregion Feedback
            }
            catch (Exception ex)
            {
                this._TbxDetails.Text += "Erreur: " + ex.Message + Environment.NewLine + ex.StackTrace + Environment.NewLine;
            }
        }
        #endregion Constructor & Public Methods

        #region Private Methods
        /// <summary>
        /// Create the output directory if it doesn't exist and makes a copy of all the references (css, images, js).
        /// </summary>
        /// <param name="outputDirectory"></param>
        private void PrepareOutput(string outputDirectory)
        {
            // Create the output directory if it doesn't exist.
            if (!Directory.Exists(outputDirectory))
                Directory.CreateDirectory(outputDirectory);

            // Performs a local copy of the css, image and javascripts folders and files.            
            foreach (string srcDirPath in Directory.GetDirectories(SOLUTION_REFERENCES_PATH, "*", SearchOption.AllDirectories))
            {
                // Copies one subdirectory.
                string tgtDirPath = srcDirPath.Replace(SOLUTION_REFERENCES_PATH, outputDirectory);
                if(!Directory.Exists(tgtDirPath))
                    Directory.CreateDirectory(tgtDirPath);

                // Copy all the files within.
                foreach (string srcFilePath in Directory.GetFiles(srcDirPath, "*.*", SearchOption.AllDirectories))
                {
                    string tgtFilePath = srcFilePath.Replace(SOLUTION_REFERENCES_PATH, outputDirectory);
                    if(!File.Exists(tgtFilePath))
                        File.Copy(srcFilePath, tgtFilePath);
                }
            }
        }

        /// <summary>
        /// Returns the HTTP 302 response url to a GET request.
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        private string GetRedirectUrl(string url)
        {
            // Request.
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";

            // Response.
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            return response.ResponseUri.AbsoluteUri;
        }
        /// <summary>
        /// Returns the HTML content of a page by a GET request.
        /// </summary>
        /// <param name="url">The url of a web page, containing GET parameters.</param>
        /// <returns>The HTML text of the requested page.</returns>
        private string GetPageHtmlByGet(string url, int pause)
        {
            // Request.
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Proxy = new WebProxy("www.candiulb.be");    // This is the most important parameter otherwise the server will timeout after a dozen of requests.
            request.Method = "GET";
            request.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
            request.Headers.Add("Accept-Encoding", "gzip, deflate");
            request.Headers.Add("Accept-Language", "en-gb,en;q=0.5");
            request.UserAgent = ".NET Framework Example Client";
            request.KeepAlive = true;

            // Pause to avoid server timeout.
            Thread.Sleep(pause);
                
            // Response.
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                //string connection = response.Headers["Connection"];
                //string proxyConnection = response.Headers["Proxy-Connection"];
                //string transferEncoding = response.Headers["Transfer-Encoding"];
                //string date = response.Headers["Date"];
                //string setCookie = response.Headers["Set-Cookie"];
                //string server = response.Headers["Server"];
                //string via = response.Headers["Via"];
                //string xPoweredBy = response.Headers["X-Powered-By"];
                //string keepAlive = response.Headers["Keep-Alive"];
                //ResponseHeader responseHeader = new ResponseHeader(connection, proxyConnection, transferEncoding, date, setCookie, server, via, xPoweredBy, keepAlive);

                using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding("ISO-8859-1")))
                {
                    return reader.ReadToEnd().Trim();
                }
            }
        }
        /// <summary>
        /// Returns the HTML content of a page by a POST request.
        /// </summary>
        /// <param name="url">The url of a web page.</param>
        /// <param name="parameters">The concatenation of the POST paramaters.</param>
        /// <returns>The HTML text of the requested page.</returns>
        private string GetPageHtmlByPost(string url, string parameters)
        {
            // Request.
            byte[] postData = Tools.TextToData(parameters);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.UserAgent = ".NET Framework Example Client";
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = postData.Length;
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(postData, 0, postData.Length);
            requestStream.Close();

            // Response.
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader responseStream = new StreamReader(response.GetResponseStream());
            return responseStream.ReadToEnd().Trim();
        }

        private string GetSearchResultPageUrl(string username)
        {
            // Get the redirect page. This is the page the redirects the user after 2 seconds IF there are results for her request.
            string redirectPageHtmlText = GetPageHtmlByPost(SEARCH_TARGET_PAGE, string.Format(SEARCH_POST_PARAMETERS, username));

            // Parse the redirect page. If the meta tag with the redirection URL is present, it means there are results for that user.
            HtmlDocument redirectPageHtml = new HtmlDocument();
            redirectPageHtml.LoadHtml(redirectPageHtmlText);
            HtmlNode redirectPageMeta = redirectPageHtml.DocumentNode.SelectSingleNode("/html/head/meta[@http-equiv='refresh']");

            if (redirectPageMeta == null)
            {
                string noSearchResultsReason;
                HtmlNode errorParagraph = redirectPageHtml.DocumentNode.SelectSingleNode("//div[@class='errorwrap']/p");
                if (errorParagraph == null)
                    noSearchResultsReason = "The user exists but has never posted on CandiULB";
                else
                    noSearchResultsReason = Tools.HtmlToText(errorParagraph.InnerText);

                throw new Exception(noSearchResultsReason);
            }
            else
            {
                string resultPageUrl = redirectPageMeta.Attributes["content"].Value;
                resultPageUrl = resultPageUrl.Substring(7, resultPageUrl.Length - 7);
                resultPageUrl = Tools.HtmlToText(resultPageUrl);
                return resultPageUrl;
            }
        }
        private int GetNumberOfResultPages(string resultPageHtmlText, out HtmlDocument resultPageHtml)
        {
            // Parse the (first) result page to get the number of result pages from a specific span.
            // If the span doesn't exist, there is only one page.
            resultPageHtml = new HtmlDocument();
            resultPageHtml.LoadHtml(resultPageHtmlText);
            HtmlNode resultPageJumpSpan = resultPageHtml.GetElementbyId("page-jump");
            int numberOfResultPages = 1;
            if (resultPageJumpSpan != null)
                numberOfResultPages = int.Parse(resultPageJumpSpan.InnerText.Replace(" Pages", string.Empty));
            return numberOfResultPages;
        }
        private void BrowseResultPage(HtmlDocument resultPageHtml, ref Dictionary<string, int> threads, ref int threadIndex, int pause, string[] excludedThreads, string outputDirectory)
        {
            // Get the thread messages on the current result page. They are all boxed in a div with class = "borderwrap".
            HtmlNodeCollection messageBoxes = resultPageHtml.DocumentNode.SelectNodes("//div[@class='borderwrap']");

            if (messageBoxes == null)
            {
                //resultPageHtml.Save(Path.Combine(outputDirectory, "log.txt"));
                File.WriteAllText(Path.Combine(outputDirectory, "log.txt"), resultPageHtml.DocumentNode.OuterHtml);
                throw new NullReferenceException("Erreur: les messages ne peuvent être extraits de la page de résultats. Voir le fichier log.txt pour feedback");
            }

            // The first and last boxes in the collection are static menus for navigation (banner & footer).
            for (int messageIndex = 1; messageIndex <= messageBoxes.Count - 2; messageIndex++)
            {
                // Thread title ->  div "borderwrap" > div "maintitle"
                string threadTitle = Tools.HtmlToText(messageBoxes[messageIndex].SelectSingleNode("div[@class='maintitle']").InnerText.TrimStart());

                // If the thread has already been treated, go straight to the next thread.
                if (threads.ContainsKey(threadTitle) || threadTitle.In(excludedThreads))
                    continue;

                // Add the thread to the collection.
                threads.Add(threadTitle, ++threadIndex);

                // Feedback.
                this._TbxDetails.Text += string.Format("{0}\t{1}{2}", threadIndex, threadTitle, Environment.NewLine);
                this._TbxDetails.Refresh();

                // Thread link  ->  div "borderwrap" > table "ipbtable" > td "row2"
                // Rows "row2" Index
                // 0    [Username]
                // 1    [Date]
                // 2    [Content]
                // 3    &nbsp;
                // 4    [Links]
                string threadLink = messageBoxes[messageIndex].SelectNodes("table[@class='ipbtable']//td[@class='row2']")[4].SelectSingleNode("a[@class='linkthru']").OuterHtml;

                // Link format  <a href="http://www.candiulb.be/forum/index.php?s=514101893b3f67020521736b836230f4&amp;act=findpost&amp;hl=&amp;pid=8773" class="linkthru">#8773</a>
                int firstQuote = threadLink.IndexOf('"');
                int secondQuote = threadLink.IndexOf('"', firstQuote + 1);
                string messageUrl = Tools.HtmlToText(threadLink.Substring(firstQuote + 1, secondQuote - firstQuote - 1));

                // At this point, there is an HTTP 302 redirection that forwards us from a message id ("pid") to a thread id ("showtopic").
                string threadLandingPageUrl = GetRedirectUrl(messageUrl);

                // URL format   http://www.candiulb.be/forum/index.php?s=c0f6166341df290da083c8a35bc21de8&showtopic=631&st=0&p=8773&#entry8773
                // By removing the additional parameters, we are sure to land on the first page of the thread.
                string threadBaseUrl = threadLandingPageUrl.Remove(threadLandingPageUrl.LastIndexOf("&st="));

                // Browse the entire thread and outputs the HTML pages.
                BrowseThread(threadBaseUrl, threadIndex, pause, outputDirectory);
            }
        }
        private void BrowseThread(string threadBaseUrl, int threadIndex, int pause, string outputDirectory)
        {
            // Get the first page.
            string pageHtmlText = GetPageHtmlByGet(threadBaseUrl, pause);

            // Parse the first page. 
            HtmlDocument pageHtml = new HtmlDocument();
            pageHtml.LoadHtml(pageHtmlText);

            // Find out how many pages are in this thread by parsing appropriate span.
            int numberOfPages = 1;
            HtmlNode pageJumpSpan = pageHtml.GetElementbyId("page-jump");
            if (pageJumpSpan != null)
                numberOfPages = int.Parse(pageJumpSpan.InnerText.Replace(" Pages", string.Empty));

            if (numberOfPages == 1)
            {
                // Save as "[threadCountIndex].html"
                string pageFileName = threadIndex + ".html";
                ArchivePage(pageFileName, pageHtmlText, outputDirectory);
            }
            else
            {
                for (int pageIndex = 1; pageIndex <= numberOfPages; pageIndex++)
                {
                    // Save as "[threadIndex].[pageIndex].html"
                    string pageFileName = threadIndex + "." + pageIndex + ".html";
                    ArchivePage(pageFileName, pageHtmlText, outputDirectory);

                    // Get next page.
                    string nextPageUrl = threadBaseUrl + "&st=" + 15 * (pageIndex);
                    pageHtmlText = GetPageHtmlByGet(nextPageUrl, pause);
                }
            }
        }
        private void ArchivePage(string pageFileName, string pageHtmlText, string outputDirectory)
        {
            // Here text substitution in the HTML of the page should be performed in order to fix local references to CSS and images.
            // CSS.
            string cssFolderPath = Path.Combine(outputDirectory, CSS_FOLDER);
            pageHtmlText = pageHtmlText.Replace("http://www.candiulb.be/forum/style_images/1_fr/folder_editor_images/", cssFolderPath);

            // Images.
            //string imagesFolderPath = "file:///" + Path.Combine(outputDirectory, IMAGES_FOLDER).Replace('\\', '/');
            string imagesFolderPath = IMAGES_FOLDER.Replace('\\', '/');
            Regex regex = new Regex(@"(^.*background.*url\()([\w/\.: -]+)(\).*$)", RegexOptions.Multiline);
            pageHtmlText = regex.Replace(pageHtmlText, "$1\"$2\"$3");
            pageHtmlText = pageHtmlText.Replace("http://www.candiulb.be/forum/style_emoticons/default/", imagesFolderPath);
            pageHtmlText = pageHtmlText.Replace("http://www.candiulb.be/squelettes/images/logos/", imagesFolderPath);
            pageHtmlText = pageHtmlText.Replace("style_images/1_fr/folder_profile_portal/", imagesFolderPath);
            pageHtmlText = pageHtmlText.Replace("style_images/1_fr/", imagesFolderPath);
            pageHtmlText = pageHtmlText.Replace("style_images/", imagesFolderPath);
            
            // Javascript.
            string jsFolderPath = JS_FOLDER;
            pageHtmlText = pageHtmlText.Replace("style_images/1_fr/folder_js_skin/", jsFolderPath);
            pageHtmlText = pageHtmlText.Replace("cache/lang_cache/fr/", jsFolderPath);
            pageHtmlText = pageHtmlText.Replace("jscripts/", jsFolderPath);

            string pageFilePath = Path.Combine(outputDirectory, pageFileName);
            File.WriteAllText(pageFilePath, pageHtmlText, Encoding.GetEncoding("ISO-8859-1"));
        }
        #endregion Private Methods
    }
}